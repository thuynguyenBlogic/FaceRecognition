﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FaceRecognition.Models
{
    public class Employee
    {
        public string Name { get; set; }
        public string Title { get; set; }
        public string PhotoUrl { get; set; }
    }
}
